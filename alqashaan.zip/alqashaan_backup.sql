﻿-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: alqashaan
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `contract_number` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `booking_date` date NOT NULL,
  `type` enum('full','men','women') NOT NULL,
  `status` enum('active','completed','cancelled') NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bookings_contract_number_unique` (`contract_number`),
  KEY `bookings_booking_date_index` (`booking_date`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (4,'0224','┘à╪¡┘à╪» ┘ü┘ç╪» ┘ç┘ä╪º┘ä','0546666039',23000.00,'2025-08-29','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(5,'0203','╪╣╪¿╪» ╪º┘ä┘ä┘ç ╪º┘ä╪╣╪¬┘è╪¿┘è','0506282577',17000.00,'2025-09-05','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(6,'0222','╪╣┘ä┘è ╪¡┘à╪»╪º┘å ╪º┘ä╪│┘è╪¡╪º┘å┘è','0551371666',16000.00,'2025-10-02','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(7,'0218','┘å┘ê╪º┘ü ╪«╪º┘ä╪» ╪┤╪»┘è╪»','0536611436',16000.00,'2025-10-03','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(8,'0221','╪º╪¡┘à╪» ╪│╪╣┘ê╪» ╪º┘ä╪º╪│╪╣╪»┘è','0564168884',25000.00,'2025-10-17','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(9,'0219','╪╣╪¿╪» ╪º┘ä╪▒╪¡┘à┘å ┘à╪▒╪▓┘ê┘é ╪º┘ä╪▒┘ü┘è╪╣╪⌐','0567511124',16000.00,'2025-10-31','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(10,'LEG-61','╪º┘à ╪│┘à╪º╪¡','0000000000',10000.00,'2025-11-01','women','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(11,'0225','┘à╪¡┘à╪» ╪▒┘ê┘è╪┤╪» ╪º┘ä╪½╪¿┘è╪¬┘è','0555461187',22000.00,'2025-11-07','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(12,'LEG-63','╪╣╪¿╪»╪º┘ä┘ä┘ç ┘ç╪▓╪º╪╣','0551131854',23000.00,'2025-11-28','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(13,'0227','╪╣╪º┘è╪╢ ╪º┘ä╪¡╪▒╪¿┘è','0538079256',23000.00,'2025-11-29','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(14,'0217','┘à╪¡┘à╪» ╪º┘ä╪╣╪¬┘è╪¿┘è ╪╣┘à╪º╪▒','0502128870',25000.00,'2025-12-05','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(15,'LEG-66','╪╣┘è╪» ╪¡╪º┘ü┘è ╪º┘ä╪╣╪¬┘è╪¿┘è','0530856053',20000.00,'2026-01-09','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(16,'233','┘ü┘è╪╡┘ä ┘å╪º┘è┘ü ╪º┘ä╪╣╪¬┘è╪¿┘è','0545060630',21000.00,'2025-12-12','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(17,'0228','┘ü┘ç╪» ┘à╪╖┘ä┘é','0559444509',17000.00,'2025-12-13','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(18,'LEG-69','╪╣┘è╪» ╪╣╪¿╪» ╪º┘ä┘à╪¡╪│┘å ╪º┘ä╪¡┘å╪¬┘ê╪┤┘è','0566340403',15000.00,'2025-11-21','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(19,'LEG-70','╪«╪º┘ä╪» ╪╣╪¿╪»╪º┘ä┘ä┘ç /╪º╪¿┘å ╪º╪«╪¬ ┘à╪┤╪╣┘ä','0505220936',0.00,'2025-12-27','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(20,'230','┘ü┘ç╪» ╪º┘ä┘ç┘à┘è╪¼╪º┘å','0556714145',23000.00,'2025-11-27','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(21,'313','╪│┘ä┘è┘à╪º┘å ┘à╪╖┘ä┘é ╪│┘ä┘è┘à╪º┘å','0535157774',21600.00,'2026-03-23','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(22,'LEG-73','╪º┘ä╪╣╪¼┘à┘è','0509502074',5000.00,'2026-05-27','women','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(23,'231','╪│╪╣╪» ╪¡╪º┘à╪» ╪º┘ä┘à╪╖┘è╪▒┘è','0551814860',23000.00,'2026-05-30','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(24,'235','╪½╪º╪¿╪¬ ╪│╪º┘ä┘à ╪º┘ä╪½╪¿┘è╪¬┘è','0553330511',23000.00,'2026-01-30','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(25,'232','┘à╪º╪¼╪» ╪╣┘ä┘è ╪º┘ä┘à╪▒┘ê┘è','0504294693',24000.00,'2026-03-26','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(26,'234','╪╡╪º┘ä╪¡ ╪º┘ä╪╣╪¬┘è╪¿┘è / ╪¿┘ä╪╣┘ê╪│','0554577511',23000.00,'2026-03-27','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(27,'236','┘å╪º╪╡╪▒ ╪«╪º┘ä╪» ╪º┘ä╪¡╪º┘ü┘è','0550024484',23000.00,'2026-10-02','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(28,'11','╪║╪º┘ä╪¿ ╪│┘è┘ü ╪º┘ä╪¡╪º┘ü┘è','0550165999',24000.00,'2026-07-10','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(29,'237','┘å╪º┘è╪╢ ╪º┘ä╪▓┘è╪º╪»┘è','0502646170',23000.00,'2026-07-31','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(30,'239','┘ü┘è╪╡┘ä ╪»╪║╪┤','0533515160',15000.00,'2026-07-03','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(31,'240','╪¬╪▒┘â┘è ╪º┘ä┘à╪┤┘ê╪¡','0554440977',24000.00,'2026-03-22','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(32,'241','╪╣╪¿╪» ╪º┘ä┘ä┘ç ╪¼┘ä┘ê┘è ╪º┘ä╪╣╪¬┘è╪¿┘è','0559053511',23000.00,'2026-05-01','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(33,'243','╪¿┘å╪»╪▒ ╪¡┘à┘ê╪» ╪º┘ä╪│┘è╪¡╪º┘å┘è','0549011457',23000.00,'2026-04-03','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(34,'246','┘à╪¡┘à╪» ┘ç╪░╪º┘ä ╪º┘ä╪¼╪░╪╣','0559511655',23000.00,'2026-08-28','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(35,'244','┘à╪╖┘ä┘é ╪º┘ä╪║╪▒╪¿┘è','0508967851',23000.00,'2026-07-04','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(36,'245','┘à╪¡┘à╪» ╪║╪º┘ü┘ä ╪º┘ä╪╣╪¬┘è╪¿┘è','0508967851',23000.00,'2026-07-02','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(37,'247','╪º┘ä┘ê┘ä┘è╪» ╪«╪º┘ä╪» ╪º┘ä┘â╪▒╪┤┘à┘è','0542223775',17000.00,'2026-06-05','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(38,'301','┘à╪┤╪º╪▒┘è ┘à╪╖┘ä┘é ╪º┘ä╪¡┘å╪¬┘ê╪┤┘è','0533322404',16000.00,'2026-04-17','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(39,'309','╪╣╪¿╪» ╪º┘ä┘ä┘ç ┘ü┘ä╪º╪¡','0502624816',14000.00,'2026-04-02','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(40,'305','┘à╪▒╪▓┘ê┘é ┘à╪¡┘à╪» ╪┤╪»┘è╪»','0538002214',16000.00,'2026-04-10','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(41,'304','╪¿╪▒┘â╪⌐ ╪¡┘à┘ê╪» ╪º┘ä╪╣╪¬┘è╪¿┘è','0504987606',17000.00,'2026-04-30','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(42,'312','┘à┘à╪»┘ê╪¡ ╪º┘ä╪¡┘å╪¬┘ê╪┤┘è','0531808008',15000.00,'2026-05-08','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(43,'308','┘ü┘ç╪» ╪║╪º╪▓┘è ╪╣┘è╪º╪»','0544744405',18000.00,'2026-05-29','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(44,'302','┘ü┘ç╪» ┘à╪¡┘à╪» ╪º┘ä╪¡┘å╪¬┘ê╪┤┘è','0556067972',20000.00,'2026-07-09','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(45,'LEG-96','╪┤╪º┘ä╪¡ ╪º┘ä╪»╪º┘ü┘ê╪▒','0509869411',24000.00,'2026-07-17','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(46,'LEG-98','╪╣╪¿╪» ╪º┘ä┘ä┘ç ╪╣┘ê╪╢ ╪º┘ä┘â╪▒╪┤┘à┘è','0504426839',6000.00,'2026-02-13','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(47,'LEG-99','╪╡╪º┘ü┘è ╪¡╪¼┘ê╪▓╪º╪¬ ┘é╪¿┘ä ╪º┘ä┘à┘ê┘é╪╣','0534863910',205766.00,'2026-03-21','full','completed','2026-06-06 10:42:59','2026-06-06 11:32:20'),(48,'330','┘å┘ê╪º╪▒ ┘à╪¡┘à╪» ╪º┘ä╪║╪▒╪¿┘è','0598054530',16000.00,'2026-05-15','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(49,'LEG-101','┘ü┘è╪¡╪º┘å ╪╣┘å╪¿╪▒','0561946764',0.00,'2026-06-04','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(50,'311','╪¿╪º╪│┘à ╪¿╪│╪º┘à ╪º┘ä╪╖┘è╪▒┘è','0561962927',23000.00,'2026-05-07','full','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(51,'317','╪╖╪º╪▒┘é ╪▓╪¿┘å ╪º┘ä┘à╪╖┘è╪▒┘è','0534348447',23000.00,'2026-06-26','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(52,'316','╪«┘ä┘ü ┘à╪»┘ê╪« ╪»┘ä┘è┘à','0553222212',16000.00,'2026-07-11','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(53,'320','╪╣╪¿╪» ╪º┘ä┘ä┘ç ╪│┘ä┘à╪º┘å ╪º┘ä╪▒┘ê┘é┘è','0508111936',22000.00,'2026-07-16','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(54,'0','┘å╪º╪╡╪▒ ╪╢┘è┘ü ╪º┘ä┘ä┘ç ╪º┘ä╪½╪¿┘è╪¬┘è','0531220307',23000.00,'2026-07-24','full','active','2026-06-06 10:42:59','2026-06-06 10:49:47'),(55,'315','┘ü┘ç╪» ╪▒╪º╪┤╪» ╪º┘ä╪╣╪¬┘è╪¿┘è','0544404456',16000.00,'2026-07-30','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(56,'318','┘è┘ê╪│┘ü ╪╣╪º┘è╪╢ ╪º┘ä┘à╪╢╪¡┘è','0504777551',23000.00,'2027-01-08','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(57,'319','╪¬╪▒┘â┘è ╪░╪╣╪º╪▒ ╪º┘ä┘å┘ü┘è╪╣┘è','0555231879',23000.00,'2026-10-30','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(58,'236-1','┘å╪º╪╡╪▒ ╪«╪º┘ä╪» ╪º┘ä╪¡╪º┘ü┘è','0550024484',23000.00,'2026-11-06','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(59,'314','┘ü╪º╪▒╪│ ┘à╪┤╪▒╪╣ ╪º┘ä╪¡╪º┘ü┘è','0505657665',23000.00,'2026-08-01','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(60,'321','╪╣╪¿╪» ╪º┘ä╪▒╪¡┘à┘å ╪º┘ä╪▒┘é╪º╪╡','0599902668',16000.00,'2026-08-27','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(61,'LEG-113','╪º┘ä╪»┘ê┘è╪▒╪¼','0541008001',5000.00,'2027-03-09','women','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(62,'322','╪º┘ä┘ê┘ä┘è╪» ╪º┘ä╪╣╪¬┘è╪¿┘è','0534383632',21000.00,'2026-07-23','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(63,'323','┘ü┘ç╪» ╪╣╪º┘è╪╢ ╪º┘ä╪▒┘é╪º╪╡','0504235406',16000.00,'2026-10-29','men','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(64,'324','╪│┘ä╪╖╪º┘å ┘â╪¿┘è╪┤╪º┘å','0504116210',22000.00,'2026-11-27','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(65,'326','┘å┘ê╪º┘ü ┘à╪¡┘à╪» ╪º┘ä╪╣╪¼┘è┘à┘è','0505220936',5000.00,'2026-05-14','men','completed','2026-06-06 10:42:59','2026-06-06 10:42:59'),(66,'329','╪╣╪¿╪»╪º┘ä╪╣╪▓┘è╪▓ ╪│┘å╪» ╪╣╪¿╪»╪º┘ä┘ä┘ç ╪º┘ä╪╣╪¬┘è╪¿┘è','0504961390',20000.00,'2026-11-26','full','active','2026-06-06 10:42:59','2026-06-06 10:42:59'),(67,'328','┘à╪│╪¬┘ê╪▒ ╪º┘ä┘â╪▒╪┤┘à┘è','0503468862',15000.00,'2026-05-31','women','completed','2026-06-06 10:42:59','2026-06-06 10:42:59');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('admin@alqshaan.com|127.0.0.1','i:1;',1780752249),('admin@alqshaan.com|127.0.0.1:timer','i:1780752249;',1780752249);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expenses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `expense_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expenses_booking_id_foreign` (`booking_id`),
  CONSTRAINT `expenses_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
INSERT INTO `expenses` VALUES (3,4,6035.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-08-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(4,5,4843.00,'┘ê╪º┘è╪¬ ┘ê┘à┘å╪╕┘ü╪º╪¬ ┘ê╪╣┘à╪º┘ä ┘ê╪º╪┤╪▒╪º┘ü ┘ê┘é┘ç┘ê╪⌐ ┘ê╪╖╪¿╪« ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-09-06','2026-06-06 10:42:59','2026-06-06 10:42:59'),(5,8,6694.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-10-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(6,7,4567.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-10-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(7,6,4820.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-10-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(8,10,2250.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-11-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(9,9,4588.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-11-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(10,11,6310.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-11-11','2026-06-06 10:42:59','2026-06-06 10:42:59'),(11,18,4825.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-11-22','2026-06-06 10:42:59','2026-06-06 10:42:59'),(12,13,6475.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(13,12,5150.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(14,20,5419.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(15,14,6400.00,'┘à╪╡╪º╪▒┘è ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(16,16,6155.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(17,17,4720.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(18,15,6333.00,'╪«╪»┘à╪º╪¬ ┘à╪¼╪º┘å┘è┘ç ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-01-10','2026-06-06 10:42:59','2026-06-06 10:42:59'),(19,24,5750.00,'╪«╪»┘à╪º╪¬ ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-01-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(20,46,700.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-02-14','2026-06-06 10:42:59','2026-06-06 10:42:59'),(21,31,6487.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-03-22','2026-06-06 10:42:59','2026-06-06 10:42:59'),(22,21,7390.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-03-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(23,25,7011.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-03-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(24,26,6400.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-03-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(25,39,4647.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-04-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(26,33,6220.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-04-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(27,38,4715.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-04-18','2026-06-06 10:42:59','2026-06-06 10:42:59'),(28,40,4600.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-04-18','2026-06-06 10:42:59','2026-06-06 10:42:59'),(29,41,4320.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-04-30','2026-06-06 10:42:59','2026-06-06 10:42:59'),(30,32,6204.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-01','2026-06-06 10:42:59','2026-06-06 10:42:59'),(31,50,6275.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-07','2026-06-06 10:42:59','2026-06-06 10:42:59'),(32,42,4300.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-08','2026-06-06 10:42:59','2026-06-06 10:42:59'),(33,65,300.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-14','2026-06-06 10:42:59','2026-06-06 10:42:59'),(34,48,5222.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-15','2026-06-06 10:42:59','2026-06-06 10:42:59'),(35,22,527.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(36,43,6260.00,'┘à╪╡╪º╪▒┘è┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(37,23,6425.00,'┘à╪╡╪▒┘ê┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-30','2026-06-06 10:42:59','2026-06-06 10:42:59'),(38,67,4565.00,'┘à╪╡╪▒┘ê┘ü ΓÇö ╪º┘ä╪¬╪╡┘å┘è┘ü: other','2026-05-31','2026-06-06 10:42:59','2026-06-06 10:42:59');
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_06_05_214434_create_personal_access_tokens_table',1),(5,'2026_06_06_000001_add_role_to_users_table',1),(6,'2026_06_06_000002_create_bookings_table',1),(7,'2026_06_06_000003_create_payments_table',1),(8,'2026_06_06_000004_create_expenses_table',1),(9,'2026_06_06_000005_add_amount_to_bookings_table',2),(10,'2026_06_06_000006_add_cancelled_status_to_bookings_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
INSERT INTO `password_reset_tokens` VALUES ('waelee2018@gmail.com','$2y$12$QBBps33qICB9jTemUIYs2u2UZd406uuf/GcD77v3Cyl6zR3Sd8PIK','2026-06-06 15:42:02');
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `booking_id` bigint(20) unsigned NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `payment_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_booking_id_foreign` (`booking_id`),
  CONSTRAINT `payments_booking_id_foreign` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (4,4,23000.00,NULL,'2025-08-17','2026-06-06 10:42:59','2026-06-06 10:42:59'),(5,7,2000.00,'╪¬╪¡┘ê┘è┘ä ╪╢┘è┘ü ╪º┘ä┘ä┘ç','2025-08-17','2026-06-06 10:42:59','2026-06-06 10:42:59'),(6,6,5000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-17','2026-06-06 10:42:59','2026-06-06 10:42:59'),(7,5,500.00,'┘â╪º╪┤','2025-08-17','2026-06-06 10:42:59','2026-06-06 10:42:59'),(8,8,5000.00,'╪¬╪¡┘ê┘è┘ä ┘à╪¡┘à╪»','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(9,9,1000.00,'┘â╪º╪┤','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(10,10,2000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(11,11,2500.00,'╪¬╪¡┘ê┘è┘ä ┘à╪¡┘à╪»','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(12,12,2000.00,'╪¬╪¡┘ê┘è┘ä ┘à╪¡┘à╪»','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(13,13,3000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(14,15,3000.00,'╪╣╪▒╪¿┘ê┘å','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(15,14,5000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(16,16,5000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(17,17,10000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(18,7,14000.00,'╪¬╪¡┘ê┘è┘ä','2025-08-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(19,5,4000.00,'┘â╪º╪┤ ╪¿╪º┘ä┘à┘â╪¬╪¿','2025-08-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(20,5,12500.00,NULL,'2025-09-06','2026-06-06 10:42:59','2026-06-06 10:42:59'),(21,20,5000.00,NULL,'2025-09-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(22,14,8000.00,NULL,'2025-09-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(23,22,500.00,'╪╣╪▒╪¿┘ê┘å','2025-09-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(24,23,5000.00,'╪╣╪▒╪¿┘ê┘å','2025-09-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(25,8,20000.00,NULL,'2025-10-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(26,6,11000.00,NULL,'2025-10-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(27,10,1000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(28,18,5000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(29,21,5000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(30,24,5000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(31,25,2000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(32,26,3000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(33,27,1000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(34,28,10000.00,NULL,'2025-10-24','2026-06-06 10:42:59','2026-06-06 10:42:59'),(35,29,5000.00,'╪¬╪¡┘ê┘è┘ä','2025-10-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(36,10,7000.00,NULL,'2025-11-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(37,9,15000.00,NULL,'2025-11-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(38,31,2000.00,'╪¬╪¡┘ê┘è┘ä','2025-11-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(39,11,19500.00,'┘å┘ç╪º╪ª┘è╪⌐','2025-11-11','2026-06-06 10:42:59','2026-06-06 10:42:59'),(40,18,10000.00,NULL,'2025-11-22','2026-06-06 10:42:59','2026-06-06 10:42:59'),(41,30,1000.00,NULL,'2025-11-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(42,32,4000.00,NULL,'2025-11-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(43,33,3000.00,NULL,'2025-11-23','2026-06-06 10:42:59','2026-06-06 10:42:59'),(44,13,20000.00,NULL,'2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(45,12,21000.00,NULL,'2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(46,20,18000.00,NULL,'2025-12-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(47,34,5000.00,NULL,'2025-12-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(48,35,2000.00,NULL,'2025-12-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(49,36,5000.00,NULL,'2025-12-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(50,37,2000.00,NULL,'2025-12-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(51,14,12000.00,NULL,'2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(52,16,16000.00,NULL,'2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(53,17,7000.00,NULL,'2025-12-13','2026-06-06 10:42:59','2026-06-06 10:42:59'),(54,38,1000.00,'╪╣╪▒╪¿┘ê┘å ╪¬╪¡┘ê┘è┘ä','2025-12-25','2026-06-06 10:42:59','2026-06-06 10:42:59'),(55,15,17000.00,'╪¬╪│┘â┘è╪▒ ╪¡╪│╪º╪¿','2026-01-10','2026-06-06 10:42:59','2026-06-06 10:42:59'),(56,39,4000.00,NULL,'2026-01-12','2026-06-06 10:42:59','2026-06-06 10:42:59'),(57,40,1000.00,NULL,'2026-01-12','2026-06-06 10:42:59','2026-06-06 10:42:59'),(58,26,5000.00,NULL,'2026-01-15','2026-06-06 10:42:59','2026-06-06 10:42:59'),(59,44,5000.00,NULL,'2026-01-15','2026-06-06 10:42:59','2026-06-06 10:42:59'),(60,45,5000.00,NULL,'2026-01-15','2026-06-06 10:42:59','2026-06-06 10:42:59'),(61,24,18000.00,'╪»┘ü╪╣┘ç ╪º╪«┘è╪▒╪⌐','2026-01-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(62,46,6000.00,NULL,'2026-02-14','2026-06-06 10:42:59','2026-06-06 10:42:59'),(63,21,16600.00,NULL,'2026-03-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(64,48,2000.00,NULL,'2026-03-21','2026-06-06 10:42:59','2026-06-06 10:42:59'),(65,31,15000.00,NULL,'2026-03-22','2026-06-06 10:42:59','2026-06-06 10:42:59'),(66,31,7000.00,'┘é╪│┘à ╪º┘ä┘å╪│╪º╪í','2026-03-22','2026-06-06 10:42:59','2026-06-06 10:42:59'),(67,25,22000.00,NULL,'2026-03-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(68,26,15000.00,NULL,'2026-03-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(69,39,10000.00,NULL,'2026-04-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(70,33,20000.00,NULL,'2026-04-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(71,38,15000.00,NULL,'2026-04-04','2026-06-06 10:42:59','2026-06-06 10:42:59'),(72,41,500.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(73,50,1500.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(74,51,1000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(75,52,6000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(76,53,5000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(77,54,5000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(78,56,5000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(79,57,3000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(80,58,1000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(81,59,5000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(82,60,2000.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(83,61,500.00,NULL,'2026-04-05','2026-06-06 10:42:59','2026-06-06 10:42:59'),(84,40,15000.00,NULL,'2026-04-18','2026-06-06 10:42:59','2026-06-06 10:42:59'),(85,41,16500.00,NULL,'2026-04-30','2026-06-06 10:42:59','2026-06-06 10:42:59'),(86,62,1000.00,'╪╣╪▒╪¿┘ê┘å','2026-04-20','2026-06-06 10:42:59','2026-06-06 10:42:59'),(87,64,5000.00,NULL,'2026-04-30','2026-06-06 10:42:59','2026-06-06 10:42:59'),(88,32,19000.00,NULL,'2026-05-01','2026-06-06 10:42:59','2026-06-06 10:42:59'),(89,65,5000.00,NULL,'2026-05-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(90,50,21500.00,NULL,'2026-05-07','2026-06-06 10:42:59','2026-06-06 10:42:59'),(91,42,6000.00,'╪╣╪▒╪¿┘ê┘å','2026-05-03','2026-06-06 10:42:59','2026-06-06 10:42:59'),(92,42,9000.00,NULL,'2026-05-08','2026-06-06 10:42:59','2026-06-06 10:42:59'),(93,66,3000.00,'╪╣╪▒╪¿┘ê┘å ╪¬╪¡┘ê┘è┘ä','2026-05-10','2026-06-06 10:42:59','2026-06-06 10:42:59'),(94,48,14000.00,'╪¬┘â┘à┘ä╪⌐ ┘à╪¿┘ä╪║ ╪º┘ä╪¡╪¼╪▓','2026-05-15','2026-06-06 10:42:59','2026-06-06 10:42:59'),(95,22,4500.00,'╪¬┘â┘à┘ä╪⌐ ╪º┘ä╪¡╪¼╪▓','2026-05-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(96,43,18000.00,NULL,'2026-05-29','2026-06-06 10:42:59','2026-06-06 10:42:59'),(97,23,18000.00,NULL,'2026-05-30','2026-06-06 10:42:59','2026-06-06 10:42:59'),(98,67,15000.00,NULL,'2026-05-31','2026-06-06 10:42:59','2026-06-06 10:42:59'),(99,47,205766.00,NULL,'2026-06-06','2026-06-06 11:32:12','2026-06-06 11:32:12');
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('12tEW5CeN4uVR4GUX1WcLFLQUB9nwFafitcRilrj',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoiSHNpMkt3OTViMzYwVHZlUmFUV3BHUXdUNFZSaG1vNkhtU2VDTEpZQiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7czo1OiJsb2dpbiI7fX0=',1780771450),('HwpwaKvtLPxTR3rzhQNzuubZ6syfNqZ2R0bGrCzr',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiS3hEZ1RTVk9XNEhub0dUdXhxWWJzUWhEWkxrbXdacG9CM212a3d2bCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjc4OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvcmVwb3J0cy9kb3dubG9hZD9mcm9tX2RhdGU9MjAyNi0wMS0wMSZ0b19kYXRlPTIwMjYtMTItMzEiO3M6NToicm91dGUiO3M6MTY6InJlcG9ydHMuZG93bmxvYWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjY0OiI4NDIzNjIyNjgxY2VjNWI2ZTgwYTdjZmJmMGY2Mjg2ZDQ2MzY4NjZkNDkwNTJhNjEzMGQ4Y2U1OTdkZDI2ZTZmIjt9',1780756872),('SVlB09zvQNTSaZPAEQYqZPkToONT68kAPFrIS4jN',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTozOntzOjY6Il90b2tlbiI7czo0MDoidEtGOEV2T3ZoY1NVdGRBOVBuaGNKeVd5MTBacWdWR1pUeTVWakFhTCI7czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czoyOToiaHR0cDovLzEyNy4wLjAuMTo4MDAwL3JlcG9ydHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',1780770696),('yg97qEL6OnrD1L8DOWYucABfGH84C4coAJUYoqAP',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36','YTo2OntzOjY6Il90b2tlbiI7czo0MDoiUFZVbmFwVGc1dmJpN3M5WXpKajBiZDhRT0RER2dydW9RcWdNOVo0dSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjc4OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvcmVwb3J0cy9kb3dubG9hZD9mcm9tX2RhdGU9MjAyNS0wNi0yNiZ0b19kYXRlPTIwMjYtMDYtMTUiO3M6NToicm91dGUiO3M6MTY6InJlcG9ydHMuZG93bmxvYWQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjY0OiI4NDIzNjIyNjgxY2VjNWI2ZTgwYTdjZmJmMGY2Mjg2ZDQ2MzY4NjZkNDkwNTJhNjEzMGQ4Y2U1OTdkZDI2ZTZmIjt9',1780762875);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL DEFAULT 'viewer',
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin User','waelee2018@gmail.com','2026-06-05 18:53:00','$2y$12$C2MH7NhEST1U22QEkxWgFecOPX/AiQuvIdIMj6poPi/i5wKncHSmG','admin','3AieII7IvZ','2026-06-05 18:53:00','2026-06-05 18:53:00'),(2,'Viewer User','viewer@alqashaan.com','2026-06-05 18:53:00','$2y$12$C2MH7NhEST1U22QEkxWgFecOPX/AiQuvIdIMj6poPi/i5wKncHSmG','viewer','wCraXm5kjGRvpntvS7k36cHXcRzgJVIKIuD9wHiIYshlGAPLpIpQpCSRbQdT','2026-06-05 18:53:00','2026-06-05 18:53:00');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-06-06 21:54:53
