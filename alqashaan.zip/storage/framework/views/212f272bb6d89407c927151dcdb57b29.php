<?php echo e($slot); ?>

<?php /**PATH C:\projects\alqashaan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>