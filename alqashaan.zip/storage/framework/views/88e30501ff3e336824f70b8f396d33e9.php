<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\projects\alqashaan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>