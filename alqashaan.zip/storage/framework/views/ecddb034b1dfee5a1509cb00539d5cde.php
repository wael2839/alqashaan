<?php echo e($slot); ?>

<?php /**PATH C:\projects\alqashaan\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>